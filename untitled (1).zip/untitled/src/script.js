let inventory = JSON.parse(localStorage.getItem("inventory")) || [];
let history = [];

function saveData() {
  localStorage.setItem("inventory", JSON.stringify(inventory));
}

/* ---------------- ADD ITEM ---------------- */
function addItem() {
  let name = document.getElementById("itemName").value;
  let qty = parseInt(document.getElementById("itemQty").value);
  let barcode = document.getElementById("barcode").value;
  let cas = document.getElementById("cas").value;
  let shelf = document.getElementById("shelf").value;

  if (!name || !qty || !barcode || !cas || !shelf) {
    alert("Fill all fields");
    return;
  }

  inventory.push({ name, qty, barcode, cas, shelf });
  saveData();
  displayInventory();
}

/* ---------------- DISPLAY INVENTORY ---------------- */
function displayInventory() {
  let table = document.getElementById("inventoryTable");
  table.innerHTML = "";

  inventory.forEach((item, i) => {
    table.innerHTML += `
      <tr class="${item.qty < 5 ? "low" : ""}">
        <td>${item.name}</td>
        <td>${item.qty}</td>
        <td>${item.barcode}</td>
        <td>${item.cas}</td>
        <td>${item.shelf}</td>
        <td>${item.qty < 5 ? "⚠ Low" : "OK"}</td>
      </tr>
    `;
  });
}

/* ---------------- BEEP SOUND ---------------- */
function beep() {
  let audio = new Audio("https://actions.google.com/sounds/v1/alarms/beep_short.ogg");
  audio.play();
}

/* ---------------- SCAN HANDLER ---------------- */
function handleScan(code) {
  let item = inventory.find(i => i.barcode === code);

  history.unshift(`Scanned: ${code}`);

  if (item) {
    item.qty += 1;
    history.unshift(`✔ Found: ${item.name} → Shelf ${item.shelf}`);
    beep();
  } else {
    history.unshift(`❌ Not found`);
  }

  saveData();
  displayInventory();
  renderHistory();
}

/* ---------------- MANUAL SCAN INPUT ---------------- */
document.getElementById("scanInput").addEventListener("keypress", function(e) {
  if (e.key === "Enter") {
    handleScan(this.value.trim());
    this.value = "";
  }
});

/* ---------------- HISTORY ---------------- */
function renderHistory() {
  document.getElementById("history").innerHTML =
    history.slice(0, 10).map(h => `<li>${h}</li>`).join("");
}

/* ---------------- CAMERA SCANNER ---------------- */
function startScanner() {
  Quagga.init({
    inputStream: {
      type: "LiveStream",
      target: document.querySelector("#scanner"),
      constraints: {
        facingMode: "environment"
      }
    },
    decoder: {
      readers: ["code_128_reader", "ean_reader", "ean_8_reader"]
    }
  }, function(err) {
    if (err) {
      console.log(err);
      return;
    }
    Quagga.start();
  });

  Quagga.onDetected(function(data) {
    let code = data.codeResult.code;
    handleScan(code);
  });
}

startScanner();
displayInventory();
renderHistory();
function stopScanner() {
  if (typeof Quagga !== "undefined") {
    Quagga.stop();
    alert("Camera stopped");
  }
}